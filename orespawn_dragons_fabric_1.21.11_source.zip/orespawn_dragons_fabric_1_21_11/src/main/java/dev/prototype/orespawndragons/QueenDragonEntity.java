package dev.prototype.orespawndragons;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.world.World;

public final class QueenDragonEntity extends DragonBossBase {
    public QueenDragonEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.setHealth(this.getMaxHealth());
    }

    @Override
    public float getScale() {
        return 2.2f;
    }

    @Override
    public int getXpToDrop() {
        return 120;
    }
}
