package dev.prototype.orespawndragons;

import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class OrespawnDragonsMod implements ModInitializer {
    public static final String MOD_ID = "orespawn_dragons";

    public static final EntityType<KingDragonEntity> THE_KING = Registry.register(
        Registries.ENTITY_TYPE,
        Identifier.of(MOD_ID, "the_king"),
        EntityType.Builder.create(KingDragonEntity::new, SpawnGroup.MONSTER)
            .dimensions(4.5f, 4.0f)
            .maxTrackingRange(10)
            .build()
    );

    public static final EntityType<QueenDragonEntity> THE_QUEEN = Registry.register(
        Registries.ENTITY_TYPE,
        Identifier.of(MOD_ID, "the_queen"),
        EntityType.Builder.create(QueenDragonEntity::new, SpawnGroup.MONSTER)
            .dimensions(4.0f, 3.5f)
            .maxTrackingRange(10)
            .build()
    );

    @Override
    public void onInitialize() {
        System.out.println("[Orespawn Dragons] Registered The King and The Queen prototypes.");
    }
}
