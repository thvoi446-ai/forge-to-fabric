package dev.prototype.orespawndragons;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.world.World;

public final class KingDragonEntity extends DragonBossBase {
    public KingDragonEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.setHealth(this.getMaxHealth());
    }

    @Override
    protected void initGoals() {
        super.initGoals();
    }

    @Override
    public float getScale() {
        return 2.6f;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return super.damage(source, Math.min(amount, 35.0f));
    }

    @Override
    public float getSoundVolume() {
        return 3.0f;
    }

    @Override
    public int getXpToDrop() {
        return 160;
    }
}
